    <?php
    phpinfo();
    ?>