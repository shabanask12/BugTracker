import React, { useState, useEffect, useCallback, useMemo } from 'react';

// --- SVG Icons (to replace react-icons) ---
const PencilIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V12h2.293l6.5-6.5z"/>
  </svg>
);

const TrashIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
    <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
  </svg>
);


// --- CSS STYLES ---
const StyleTag = () => (
  <style>{`
    :root {
      --primary-bg: #f4f7fa; --content-bg: #ffffff; --border-color: #e5e7eb; --text-primary: #111827;
      --text-secondary: #6b7280; --button-primary-bg: #3498db; --button-primary-hover: #2980b9;
      --button-danger-bg: #e74c3c; --button-danger-hover: #c0392b;
      --shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: var(--primary-bg); color: var--text-primary; }
    .main-content { max-width: 1400px; margin: 0 auto; padding: 2rem; }
    
    /* --- FILTER BAR STYLES --- */
    .controls-header { padding: 1rem 1.5rem; background-color: var(--content-bg); border-radius: 8px 8px 0 0; box-shadow: var(--shadow); display: flex; justify-content: space-between; align-items: center; gap: 1.5rem; flex-wrap: wrap; border-bottom: 1px solid var(--border-color); }
    .filters-wrapper { display: flex; align-items: center; gap: 1.5rem; flex-wrap: wrap; }
    .filter-item { display: flex; flex-direction: column; }
    .filter-item label { font-size: 0.8rem; font-weight: 600; color: var(--text-secondary); margin-bottom: 0.25rem; }
    .filter-item input { padding: 0.6rem; border: 1px solid var(--border-color); border-radius: 6px; width: 220px; font-family: inherit; }
    .date-filter-input { width: 140px !important; }

    /* --- PRIORITY TABS --- */
    .priority-tabs {
        display: flex;
        gap: 0.5rem;
        padding: 0.75rem 1.5rem;
        background-color: var(--content-bg);
    }
    .priority-tab-btn {
        padding: 0.5rem 1rem;
        border: 1px solid transparent;
        background-color: #f9fafb;
        color: var(--text-secondary);
        font-weight: 600;
        cursor: pointer;
        border-radius: 6px;
        transition: background-color 0.2s, color 0.2s, border-color 0.2s;
    }
    .priority-tab-btn:hover {
        background-color: #f3f4f6;
        color: var(--text-primary);
    }
    .priority-tab-btn.active {
        color: var(--button-primary-bg);
        background-color: #e9f5ff;
        border-color: var(--button-primary-bg);
    }

    /* --- TABLE STYLES --- */
    .bug-list-container { background-color: var(--content-bg); padding: 1.5rem; border-radius: 0 0 8px 8px; box-shadow: var(--shadow); overflow-x: auto; margin-top: -1px;}
    .custom-table { width: 100%; border-collapse: collapse; }
    .custom-table th, .custom-table td { padding: 12px 15px; text-align: left; border-bottom: 1px solid var(--border-color); vertical-align: middle; }
    .custom-table thead th { background-color: #f9fafb; font-size: 12px; color: var(--text-secondary); font-weight: bold; text-transform: uppercase; cursor: pointer; }
    .custom-table tbody tr { transition: background-color 0.2s; }
    .custom-table tbody tr:hover { background-color: #f3f4f6; }
    .actions-cell { display: flex; align-items: center; gap: 15px; }
    .icon-btn { background: none; border: none; cursor: pointer; padding: 5px; margin: 0; font-size: 14px; color: var(--text-secondary); transition: color 0.2s, transform 0.2s; }
    .icon-btn:hover { transform: scale(1.1); color: var(--button-primary-bg); }
    .icon-btn.delete:hover { color: var(--button-danger-bg); }
    
    /* --- MODAL, FORM, and GRID STYLES --- */
    .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.6); display: flex; align-items: center; justify-content: center; z-index: 1000; backdrop-filter: blur(4px); }
    .modal-content { background: var(--content-bg); padding: 2rem; border-radius: 8px; width: 800px; max-width: 90%; box-shadow: 0 5px 15px rgba(0,0,0,0.3); position: relative; max-height: 90vh; overflow-y: auto; }
    .modal-close-button { position: absolute; top: 10px; right: 15px; background: transparent; border: none; font-size: 1.8rem; color: var(--text-secondary); cursor: pointer; }
    .form-container, .view-bug-container { width: 100%; }
    .form-container h2, .view-bug-container h2 { margin-top: 0; margin-bottom: 1.5rem; color: var(--text-primary); text-align: center; }
    .form-group { margin-bottom: 1rem; }
    .form-group label, .view-group strong { display: block; margin-bottom: 0.5rem; font-weight: 600; color: #374151; font-size: 0.9rem; }
    .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 6px; font-size: 1rem; box-sizing: border-box; color: #111827; }
    .view-group { margin-bottom: 0.8rem; }
    .view-group p { margin: 0; padding: 0; line-height: 1.5; word-wrap: break-word; color: #4b5563; }
    .view-group a { color: var(--button-primary-bg); text-decoration: none; font-weight: bold; }
    .row { display: flex; flex-wrap: wrap; margin: 0 -10px; }
    .col-md-6, .col-md-12 { padding: 0 10px; box-sizing: border-box; }
    .col-md-6 { width: 50%; }
    .col-md-12 { width: 100%; }
    
    /* --- BUTTONS, MESSAGES, BADGES --- */
    .create-bug-button, .submit-button { padding: 0.75rem 1.5rem; border: none; border-radius: 6px; background-color: var(--button-primary-bg); color: white; font-size: 1rem; font-weight: bold; cursor: pointer; transition: background-color 0.2s; }
    .submit-button { width: 100%; margin-top: 1rem; }
    .message { margin-top: 1rem; padding: 0.75rem; border-radius: 6px; text-align: center; }
    .message.success { background-color: #d1fae5; color: #065f46; }
    .message.error { background-color: #fee2e2; color: #991b1b; }
    .badge { display: inline-block; padding: 0.25em 0.75em; border-radius: 9999px; font-weight: 600; font-size: 0.75rem; line-height: 1.5; text-transform: capitalize; }
    .badge-priority-critical { background-color: #fee2e2; color: #991b1b; }
    .badge-priority-high { background-color: #ffedd5; color: #9a3412; }
    .badge-priority-normal { background-color: #dbeafe; color: #1e40af; }
    .badge-priority-low { background-color: #e0e7ff; color: #3730a3; }
    .badge-not-started { background-color: #e5e7eb; color: #4b5563; }
    .badge-in-progress { background-color: #fef3c7; color: #92400e; }
    .badge-resolved { background-color: #d1fae5; color: #065f46; }
    .spinner { border: 4px solid rgba(0, 0, 0, 0.1); width: 36px; height: 36px; border-radius: 50%; border-left-color: var(--button-primary-bg); animation: spin 1s linear infinite; margin: 2rem auto; }
    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    
    /* Confirmation Dialog */
    .confirm-dialog { text-align: center; }
    .confirm-dialog h3 { margin-top: 0; }
    .confirm-dialog p { margin-bottom: 1.5rem; color: var(--text-secondary); }
    .confirm-dialog-actions button { padding: 0.6rem 1.5rem; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; margin: 0 0.5rem; }
    .confirm-btn { background-color: var(--button-danger-bg); color: white; }
    .cancel-btn { background-color: #e5e7eb; color: #4b5563; }
  `}</style>
);

// --- HELPER & CHILD COMPONENTS ---

const Modal = ({ children, onClose }) => (
  <div className="modal-overlay" onClick={onClose}>
    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
      <button className="modal-close-button" onClick={onClose}>&times;</button>
      {children}
    </div>
  </div>
);

const Badge = ({ text, type }) => <span className={`badge badge-${type}`}>{text || 'N/A'}</span>;

// Generic form component for creating and editing bugs
const BugForm = ({ bug, onFormSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    title: bug?.title || '',
    project_id: bug?.project_id || '',
    customer_impact: bug?.customer_impact || '',
    source: bug?.source || '',
    action_required: bug?.action_required || '',
    priority: bug?.priority || 'Normal',
    assigned_to: bug?.assigned_to || '',
    status: bug?.status || 'Not Started',
  });
  const [attachment, setAttachment] = useState(null);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [options, setOptions] = useState({ customer_impacts: [], sources: [], assign_options: [], projects: [] });

  const isEditMode = !!bug;

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const [bugOptionsResponse, assignResponse, projectsResponse] = await Promise.all([
          fetch("http://localhost/BugTracker/api/bug/get_bug_options.php"),
          fetch("http://localhost/BugTracker/api/user/get_active_users_for_assignment.php"),
          fetch("http://localhost/BugTracker/api/project/get_active_projects.php")
        ]);
        if (!bugOptionsResponse.ok || !assignResponse.ok || !projectsResponse.ok) throw new Error('Failed to fetch form options');
        const [bugOptionsData, assignData, projectsData] = await Promise.all([bugOptionsResponse.json(), assignResponse.json(), projectsResponse.json()]);
        setOptions({
          customer_impacts: bugOptionsData.customer_impacts || [],
          sources: bugOptionsData.sources || [],
          assign_options: assignData.assign_options || [],
          projects: projectsData.records || []
        });
      } catch (error) {
        setMessage(`Error fetching options: ${error.message}`);
        setMessageType('error');
      }
    };
    fetchOptions();
  }, []);

  const handleChange = (e) => setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  const handleFileChange = (e) => setAttachment(e.target.files[0]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');

    const url = isEditMode
      ? "http://localhost/BugTracker/api/bug/update_bug.php"
      : "http://localhost/BugTracker/api/bug/create_bug.php";

    const dataToSubmit = new FormData();
    Object.keys(formData).forEach(key => dataToSubmit.append(key, formData[key]));
    if (isEditMode) {
      dataToSubmit.append('id', bug.id);
    }
    if (attachment) {
      dataToSubmit.append('attachment', attachment);
    }

    try {
      const response = await fetch(url, { method: "POST", body: dataToSubmit });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || `Failed to ${isEditMode ? 'update' : 'create'} bug.`);
      
      setMessage(`Bug ${isEditMode ? 'updated' : 'created'} successfully!`);
      setMessageType('success');
      setTimeout(() => { onFormSubmit(); }, 1200);
    } catch (error) {
      setMessage(`Error: ${error.message}`);
      setMessageType('error');
    }
  };

  return (
    <div className="form-container">
      <h2>{isEditMode ? 'Edit Bug' : 'Create New Bug'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-12"><div className="form-group"><label>Title</label><input type="text" name="title" value={formData.title} onChange={handleChange} required /></div></div>
          <div className="col-md-6"><div className="form-group"><label>Project</label><select name="project_id" value={formData.project_id} onChange={handleChange} required><option value="">Select Project</option>{options.projects.map((p) => (<option key={p.id} value={p.id}>{p.name}</option>))}</select></div></div>
          <div className="col-md-6"><div className="form-group"><label>Priority</label><select name="priority" value={formData.priority} onChange={handleChange}><option>Low</option><option>Normal</option><option>High</option><option>Critical</option></select></div></div>
          <div className="col-md-6"><div className="form-group"><label>Customer Impact</label><select name="customer_impact" value={formData.customer_impact} onChange={handleChange} required><option value="">Select Impact</option>{options.customer_impacts.map((o, i) => (<option key={i} value={o}>{o}</option>))}</select></div></div>
          <div className="col-md-6"><div className="form-group"><label>Source</label><select name="source" value={formData.source} onChange={handleChange} required><option value="">Select Source</option>{options.sources.map((o, i) => (<option key={i} value={o}>{o}</option>))}</select></div></div>
          <div className="col-md-12"><div className="form-group"><label>Action Required</label><textarea name="action_required" value={formData.action_required} onChange={handleChange} required /></div></div>
          <div className="col-md-6"><div className="form-group"><label>Assign To</label><select name="assigned_to" value={formData.assigned_to} onChange={handleChange}><option value="">Unassigned</option>{options.assign_options.map((o) => (<option key={o.id} value={o.id}>{o.name}</option>))}</select></div></div>
          {isEditMode && <div className="col-md-6"><div className="form-group"><label>Status</label><select name="status" value={formData.status} onChange={handleChange}><option>Not Started</option><option>In Progress</option><option>Resolved</option></select></div></div>}
          <div className="col-md-6"><div className="form-group"><label>Attach New File (Optional)</label><input type="file" name="attachment" onChange={handleFileChange} /></div></div>
        </div>
        <button type="submit" className="submit-button">{isEditMode ? 'Save Changes' : 'Submit Bug'}</button>
      </form>
      {message && <p className={`message ${messageType}`}>{message}</p>}
    </div>
  );
};

const ViewBugModal = ({ bug, onClose }) => {
    if (!bug) return null;
    const attachmentUrl = bug.attachment_path ? `http://localhost/BugTracker/api/uploads/${bug.attachment_path}` : null;

    return (
        <Modal onClose={onClose}>
            <div className="view-bug-container">
                <h2>Bug Details</h2>
                <div className="row">
                    <div className="col-md-12"><div className="view-group"><strong>Title</strong><p>{bug.title}</p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Project</strong><p>{bug.project_name || 'N/A'}</p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Assigned To</strong><p>{bug.assigned_to_name || 'Unassigned'}</p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Status</strong><p><Badge text={bug.status} type={bug.status?.toLowerCase().replace(' ', '-') || 'default'} /></p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Priority</strong><p><Badge text={bug.priority} type={`priority-${bug.priority?.toLowerCase() || 'normal'}`} /></p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Customer Impact</strong><p>{bug.customer_impact}</p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Source</strong><p>{bug.source}</p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Created At</strong><p>{new Date(bug.created_at).toLocaleString()}</p></div></div>
                    <div className="col-md-6"><div className="view-group"><strong>Attachment</strong>{attachmentUrl ? <p><a href={attachmentUrl} target="_blank" rel="noopener noreferrer">View Attachment</a></p> : <p>None</p>}</div></div>
                    <div className="col-md-12"><div className="view-group"><strong>Action Required</strong><p style={{whiteSpace: 'pre-wrap'}}>{bug.action_required}</p></div></div>
                </div>
            </div>
        </Modal>
    );
};

const ConfirmDeleteModal = ({ bug, onConfirm, onCancel, isDeleting }) => (
    <Modal onClose={onCancel}>
      <div className="confirm-dialog">
        <h3>Confirm Deletion</h3>
        <p>Are you sure you want to delete the bug titled "<strong>{bug.title}</strong>"? This action cannot be undone.</p>
        <div className="confirm-dialog-actions">
          <button className="cancel-btn" onClick={onCancel} disabled={isDeleting}>Cancel</button>
          <button className="confirm-btn" onClick={() => onConfirm(bug.id)} disabled={isDeleting}>
            {isDeleting ? 'Deleting...' : 'Delete'}
          </button>
        </div>
      </div>
    </Modal>
);

const SimpleDataTable = ({ columns, data, onRowClick, onEdit, onDelete }) => {
  const [sortConfig, setSortConfig] = useState({ key: 'created_at', direction: 'descending' });

  const sortedData = useMemo(() => {
    let sortableData = [...data];
    if (sortConfig.key) {
      sortableData.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) return sortConfig.direction === 'ascending' ? -1 : 1;
        if (a[sortConfig.key] > b[sortConfig.key]) return sortConfig.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }
    return sortableData;
  }, [data, sortConfig]);

  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const handleRowClick = (e, row) => {
    if (e.target.closest('.actions-cell')) {
        return;
    }
    onRowClick(row);
  };
  
  return (
    <table className="custom-table">
      <thead>
        <tr>
          {columns.map(col => <th key={col.key} onClick={() => col.sortable && requestSort(col.key)}>{col.name}</th>)}
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {sortedData.length > 0 ? sortedData.map(row => (
          <tr key={row.id} onClick={(e) => handleRowClick(e, row)} style={{cursor: 'pointer'}}>
            {columns.map(col => <td key={col.key}>{col.cell ? col.cell(row) : row[col.key]}</td>)}
             <td className="actions-cell">
                <button className="icon-btn" title="Edit" onClick={() => onEdit(row)}>
                    <PencilIcon />
                </button>
                <button className="icon-btn delete" title="Delete" onClick={() => onDelete(row)}>
                    <TrashIcon />
                </button>
            </td>
          </tr>
        )) : (
          <tr>
            <td colSpan={columns.length + 1} style={{ textAlign: 'center', padding: '2rem' }}>No bugs match your filters.</td>
          </tr>
        )}
      </tbody>
    </table>
  );
};

// --- MAIN PAGE COMPONENT ---
function CreateBugPage() {
  const [bugs, setBugs] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modal, setModal] = useState({ type: null, data: null });
  
  const [searchQuery, setSearchQuery] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('All'); // State for priority filter

  const fetchBugs = useCallback(async () => {
    setIsLoading(true); 
    setError(null);
    try {
      const response = await fetch("http://localhost/BugTracker/api/bug/get_bugs.php");
      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
      const data = await response.json();
      setBugs(data.records || []);
    } catch (e) {
      setError(`Failed to fetch bugs: ${e.message}.`);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => { fetchBugs(); }, [fetchBugs]);

  const closeModal = () => setModal({ type: null, data: null });
  const refreshAndClose = () => {
    closeModal();
    fetchBugs();
  };
  
  const handleDelete = async (bugId) => {
    try {
      const response = await fetch("http://localhost/BugTracker/api/bug/delete_bug.php", {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: bugId })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Failed to delete bug.');
      refreshAndClose();
    } catch (error) {
      alert(`Error: ${error.message}`);
      closeModal();
    }
  };

  const filteredBugs = useMemo(() => {
    return bugs.filter(bug => {
      // Search filter
      const searchMatch = searchQuery.toLowerCase() === '' ||
        bug.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (bug.project_name && bug.project_name.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (bug.assigned_to_name && bug.assigned_to_name.toLowerCase().includes(searchQuery.toLowerCase()));
      
      // Date filter
      const dateMatch = (!startDate || new Date(bug.created_at) >= new Date(startDate)) &&
                        (!endDate || new Date(bug.created_at) <= new Date(endDate).setHours(23, 59, 59, 999));

      // Priority Filter
      const priorityMatch = priorityFilter === 'All' || bug.priority === priorityFilter;

      return searchMatch && dateMatch && priorityMatch;
    });
  }, [bugs, searchQuery, startDate, endDate, priorityFilter]);

  const columns = [
    { name: 'Title', key: 'title', sortable: true },
    { name: 'Project', key: 'project_name', sortable: true },
    { name: 'Status', key: 'status', sortable: true, cell: row => <Badge text={row.status} type={row.status?.toLowerCase().replace(' ', '-')} /> },
    { name: 'Priority', key: 'priority', sortable: true, cell: row => <Badge text={row.priority} type={`priority-${row.priority?.toLowerCase()}`} /> },
    { name: 'Assigned To', key: 'assigned_to_name', sortable: true, cell: row => row.assigned_to_name || 'Unassigned' },
    { name: 'Created At', key: 'created_at', sortable: true, cell: row => new Date(row.created_at).toLocaleDateString() },
  ];
  
  const priorities = ['All', 'Low', 'Normal', 'High', 'Critical'];

  const renderModal = () => {
    const { type, data } = modal;
    switch(type) {
      case 'create':
        return <Modal onClose={closeModal}><BugForm onFormSubmit={refreshAndClose} onCancel={closeModal} /></Modal>;
      case 'edit':
        return <Modal onClose={closeModal}><BugForm bug={data} onFormSubmit={refreshAndClose} onCancel={closeModal} /></Modal>;
      case 'view':
        return <ViewBugModal bug={data} onClose={closeModal} />;
      case 'delete':
        return <ConfirmDeleteModal bug={data} onConfirm={handleDelete} onCancel={closeModal} />;
      default:
        return null;
    }
  };

  return (
    <>
      <StyleTag />
      <main className="main-content">
        {renderModal()}
        <div className="controls-header">
          <div className="filters-wrapper">
            <div className="filter-item">
              <label htmlFor="search-filter">Search</label>
              <input 
                id="search-filter" type="text" placeholder="Search title, project..." 
                value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} 
              />
            </div>
            <div className="filter-item">
              <label>Created From</label>
              <input type="date" className="date-filter-input" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            </div>
            <div className="filter-item">
                <label>Created To</label>
                <input type="date" className="date-filter-input" value={endDate} onChange={(e) => setEndDate(e.target.value)} min={startDate} />
            </div>
          </div>
          <button className="create-bug-button" onClick={() => setModal({ type: 'create', data: null })}>+ New Bug</button>
        </div>
        
        <div className="priority-tabs">
            {priorities.map(p => (
                <button
                    key={p}
                    className={`priority-tab-btn ${priorityFilter === p ? 'active' : ''}`}
                    onClick={() => setPriorityFilter(p)}
                >
                    {p}
                </button>
            ))}
        </div>

        <div className="bug-list-container">
          {isLoading && <div className="spinner"></div>}
          {error && <p className="error-message">{error}</p>}
          {!isLoading && !error && (
            <SimpleDataTable 
                columns={columns} 
                data={filteredBugs} 
                onRowClick={(bug) => setModal({ type: 'view', data: bug })}
                onEdit={(bug) => setModal({ type: 'edit', data: bug })}
                onDelete={(bug) => setModal({ type: 'delete', data: bug })}
            />
          )}
        </div>
      </main>
    </>
  );
}

export default CreateBugPage;

