<?php
ob_start();
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
// ... (rest of headers)

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

include_once '../../config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    $data = json_decode(file_get_contents("php://input"));

    if (!isset($data->id) || !isset($data->status)) {
        http_response_code(400);
        echo json_encode(["message" => "Bug ID and status are required."]);
        exit();
    }

    $query = "UPDATE bug_reports SET status = :status WHERE id = :id";
    $stmt = $db->prepare($query);

    $stmt->bindParam(':id', $data->id);
    $stmt->bindParam(':status', $data->status);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Bug status updated."]);
    } else {
        http_response_code(503);
        echo json_encode(["message" => "Unable to update bug status."]);
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["message" => "Internal Server Error: " . $e->getMessage()]);
}
ob_end_flush();
?>