<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include_once '../../config/database.php';

$database = new Database();
$db = $database->getConnection();

// This query selects all users and aliases the 'name' column to 'username'
// so the frontend table can display it correctly.
$query = "SELECT id, name as username, email, role, status, created_at FROM users ORDER BY id ASC";

$stmt = $db->prepare($query);
$stmt->execute();

$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

http_response_code(200);
echo json_encode($users);
?>